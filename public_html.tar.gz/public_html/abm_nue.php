<!DOCTYPE html>
<html lang="es">
<head>
  <title>Trivia Preguntas y Respuestas</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=ZCOOL+KuaiLe&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Press+Start+2P&display=swap" rel="stylesheet">

<link rel="stylesheet" href="/css-trivia/estilo-abm_nue.css">
<link rel="stylesheet" href="/css-trivia/footer.css">

 
</head>
<body>
<?php
include("header_nue.php");
?>

        	<div class="container">
     <section>
    <div class="menuBotones">
    <br>
      <h3>AQUI PUEDE REALIZAR MODIFICACIONES A/B/M EN CARACTER DE ARMINISTRADOR</h3>
      <div class="btn-group" role="group" aria-label="Basic example">
        <button type="button"onclick="location.href = 'alta_nue.php'" class="btn btn-secondary">AGREGAR NUEVA PREGUNTA</button>
        </div>
        <div class="btn-group" role="group" aria-label="Basic example">
        <button type="button" class="btn btn-secondary">BORRAR PREGUNTA</button>
        </div>
        <div class="btn-group" role="group" aria-label="Basic example">
        <button type="button" class="btn btn-secondary">MODIFICAR PREGUNTA</button>
      </div>
    </div>
  </section>
  </div>

  

<?php
include("footer_nue.php");
?>
</body>
</html>