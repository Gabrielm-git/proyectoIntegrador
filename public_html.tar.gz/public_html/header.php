<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="/css-trivia/estilo-header.css">
  </head>
  <body>
    <header>
      <nav class="navegacion">
        <div class="titulo">
          <h1>Trivia</h1>
        </div>
        <ul class="menu">
          <li><a href="registrarvista.php">Registrate</a></li>
          <li><a href="login.php">Iniciar Sesión</a></li>
          <li><a href="faq.php" >Preguntas Frecuentes</a></li>
          <li><a href="home.php">Inicio</a></li>
        </ul>
      </nav>
    </header>

  </body>
</html>