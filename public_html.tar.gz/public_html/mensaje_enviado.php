<!DOCTYPE html >
<html>
<head>
<meta charset="utf-8" />
<title>Programador web con PHP y MySQL</title>
<link href="estilos.css" rel="stylesheet"/>
</head>

<body>
<section id="contenedor">
	<?php
include("cabecera.php");
?>
    <section id="contenido">
    <h2>Mensaje enviado</h2>
    <p>El Mensaje fue enviado correctamente</p> 



    </section>


<?php
include("pie.php");
?>
</section>
</body>
</html>