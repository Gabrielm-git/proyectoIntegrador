<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Preguntas y Respuestas</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index_nue.php">Inicio</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Desplegable<span class="caret"></span></a>
        */<ul class="dropdown-menu">
          <li><a href="#">Pagina 1-1</a></li>
          <li><a href="#">Pagina 1-2</a></li>
          <li><a href="#">Pagina 1-3</a></li>
        </ul>*/
      </li>
      <li><a href="ranking_nue.php">Ranking</a></li>
      <li><a href="contacto_nue.php">Contacto</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="login_nue.php"><span class="glyphicon glyphicon-user"></span> Registrase</a></li>
      <li><a href="registrarvista_nue.php"><span class="glyphicon glyphicon-log-in"></span> Acceder</a></li>
    </ul>
  </div>
</nav>