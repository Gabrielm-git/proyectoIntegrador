<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="/css-trivia/estilo-home.css">
  <link href="https://fonts.googleapis.com/css?family=ZCOOL+KuaiLe&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>

<body>
  <?php
  include ("header.php");
   ?>
  <div class="container">
    <section>
<h3>AQUI PUEDE REALIZAR MODIFICACIONES A/B/M EN CARACTER DE ARMINISTRADOR</h3>
      Preguntas Frecuentes
    </section>
  </div>
    <?php
    include ("footer.php");
     ?>
</body>
</html>