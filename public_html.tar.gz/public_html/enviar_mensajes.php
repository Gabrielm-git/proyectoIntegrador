<?php

header("Location: mensaje_enviados.php");
?>